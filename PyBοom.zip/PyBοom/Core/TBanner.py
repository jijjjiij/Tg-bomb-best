from colorama import Fore, Style
import socket



_banner = '''
    _____   _______ ________  ______
   /  _/ | / / ___//  _/ __ \/ ____/
   / //  |/ /\__ \ / // / / / __/   
 _/ // /|  /___/ // // /_/ / /___   
/___/_/ |_//____/___/_____/_____/
'''



def get_local_ip():
    '''Получение локального IP адреса'''
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"



def banner(host, port):
    '''Вывод баннера с ссылкой'''
    
    local_ip = get_local_ip()
    
    print(Style.RESET_ALL + _banner)
    if host == '0.0.0.0':
        print(f'Локальный адрес: http://127.0.0.1:{port}')
        print(f'Сетевой адрес: http://{local_ip}:{port}')
    else:
        print(f'Адрес: http://{host}:{port}')
        if local_ip != host and local_ip != '127.0.0.1':
            print(f'Сетевой адрес: http://{local_ip}:{port}')
    print()